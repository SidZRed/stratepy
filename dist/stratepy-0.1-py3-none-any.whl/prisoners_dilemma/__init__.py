from .game import PrisonersDilemma
from .strategies import tit_for_tat, susp_tit_for_tat, always_cooperate, always_defect, random_strategy, probable_coop, grim, pavlov, n_pavlov, reactive, memory_one